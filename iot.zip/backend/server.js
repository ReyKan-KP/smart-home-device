const BluetoothSerialPort =
  require("bluetooth-serial-port").BluetoothSerialPort;
const WebSocket = require("ws");

// Initialize Bluetooth and WebSocket server
const btSerial = new BluetoothSerialPort();
const wss = new WebSocket.Server({ port: 8080 });

// MAC address of your HC-05 Bluetooth module
const BLUETOOTH_DEVICE_ADDRESS = "00:23:10:A0:55:CC";

// Connect to HC-05
btSerial.findSerialPortChannel(
  BLUETOOTH_DEVICE_ADDRESS,
  (channel) => {
    btSerial.connect(
      BLUETOOTH_DEVICE_ADDRESS,
      channel,
      () => {
        console.log("Connected to HC-05 Bluetooth module");

        // Read data from HC-05 and broadcast to WebSocket clients
        btSerial.on("data", (buffer) => {
          const data = buffer.toString("utf-8");
          console.log(`Received from Bluetooth: ${data}`);

          // Broadcast to all connected WebSocket clients
          wss.clients.forEach((client) => {
            if (client.readyState === WebSocket.OPEN) {
              client.send(JSON.stringify({ type: "bluetooth-data", data }));
            }
          });
        });
      },
      () => {
        console.error("Failed to connect to the Bluetooth device.");
      }
    );
  },
  () => {
    console.error("Could not find serial port channel.");
  }
);

// Handle WebSocket connections from the React frontend
wss.on("connection", (ws) => {
  console.log("WebSocket client connected");

  // Receive commands from the React frontend
  ws.on("message", (message) => {
    const { command } = JSON.parse(message);
    console.log(`Received command from client: ${command}`);

    // Send the command to the HC-05
    btSerial.write(Buffer.from(command, "utf-8"), (err, bytesWritten) => {
      if (err) {
        console.error("Error writing to Bluetooth device:", err);
      } else {
        console.log(`Sent to Bluetooth: ${command}`);
      }
    });
  });

  // Notify when WebSocket client disconnects
  ws.on("close", () => {
    console.log("WebSocket client disconnected");
  });
});

// Error handling for Bluetooth events
btSerial.on("failure", (err) => {
  console.error("Bluetooth connection failed:", err);
});

btSerial.on("closed", () => {
  console.log("Bluetooth connection closed");
});

console.log("Server is running. WebSocket listening on ws://localhost:8080");
